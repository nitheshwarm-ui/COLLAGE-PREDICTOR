"""
CUTOFF COMPASS - Backend API
Flask backend for the TNEA College Predictor frontend.

Mirrors the exact prediction logic from the frontend JS (calcProbability,
getTier, getTierLabel) so behavior is identical whether computed client-side
or server-side.
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import json
import os

app = Flask(__name__)
CORS(app)  # allow the frontend (different origin/port) to call this API

DATA_FILE = os.path.join(os.path.dirname(__file__), "data.json")

with open(DATA_FILE, "r", encoding="utf-8") as f:
    DATA = json.load(f)

BRANCH_SHORT = {
    "Computer Science Engineering": "CSE",
    "Electronics and Communication Engineering": "ECE",
    "Artificial Intelligence and Data Science": "AI&DS",
    "Mechanical Engineering": "Mech",
}


# ---------- Core prediction logic (same rules as the frontend) ----------

def calc_probability(score, cutoff):
    diff = score - cutoff
    if diff >= 2:
        return 95
    if diff >= 1:
        return 88
    if diff >= 0:
        return 75
    if diff >= -1:
        return 55
    if diff >= -2:
        return 35
    if diff >= -3:
        return 18
    if diff >= -5:
        return 8
    return 3


def get_tier(pct):
    if pct >= 70:
        return "high"
    if pct >= 35:
        return "medium"
    return "low"


def get_tier_label(pct):
    if pct >= 70:
        return "Likely"
    if pct >= 35:
        return "Moderate"
    return "Unlikely"


# ---------------------------- Routes -------------------------------------

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "records": len(DATA)})


@app.route("/api/meta", methods=["GET"])
def meta():
    """Returns dropdown options (colleges, branches, communities) so the
    frontend can populate filters without hardcoding the DATA array."""
    colleges = sorted({d["college"] for d in DATA})
    branches = sorted({d["branch"] for d in DATA})
    communities = sorted({d["community"] for d in DATA})
    return jsonify({
        "colleges": colleges,
        "branches": branches,
        "communities": communities,
        "branch_short": BRANCH_SHORT,
    })


@app.route("/api/predict", methods=["POST"])
def predict():
    body = request.get_json(silent=True) or {}

    try:
        score = float(body.get("score"))
    except (TypeError, ValueError):
        return jsonify({"error": "A valid numeric 'score' is required."}), 400

    community = body.get("community", "")
    branch = body.get("branch", "")
    year = str(body.get("year", "2025"))

    if not community:
        return jsonify({"error": "'community' is required."}), 400
    if score < 0 or score > 200:
        return jsonify({"error": "Score must be between 0 and 200."}), 400
    if year not in ("2023", "2024", "2025"):
        return jsonify({"error": "Year must be 2023, 2024, or 2025."}), 400

    cutoff_key = f"cutoff_{year}"

    filtered = [d for d in DATA if d["community"] == community]
    if branch:
        filtered = [d for d in filtered if d["branch"] == branch]

    results = []
    for d in filtered:
        cutoff = d[cutoff_key]
        prob = calc_probability(score, cutoff)
        results.append({
            **d,
            "cutoff": cutoff,
            "probability": prob,
            "tier": get_tier(prob),
            "tier_label": get_tier_label(prob),
        })

    # Sort: highest probability first, then highest cutoff
    results.sort(key=lambda r: (-r["probability"], -r["cutoff"]))

    # Deduplicate by college+branch (keep best match found first)
    seen = set()
    unique = []
    for r in results:
        key = (r["college"], r["branch"])
        if key not in seen:
            seen.add(key)
            unique.append(r)

    high_count = sum(1 for r in unique if r["probability"] >= 70)
    med_count = sum(1 for r in unique if 35 <= r["probability"] < 70)

    return jsonify({
        "score": score,
        "community": community,
        "branch": branch,
        "year": year,
        "total_matches": len(unique),
        "high_count": high_count,
        "medium_count": med_count,
        "results": unique,
    })


@app.route("/api/table", methods=["GET"])
def table():
    """Data explorer endpoint — supports the same filters as the frontend's
    Data Explorer table (college, branch, community), passed as query params."""
    college = request.args.get("college", "")
    branch = request.args.get("branch", "")
    community = request.args.get("community", "")

    filtered = DATA
    if college:
        filtered = [d for d in filtered if d["college"] == college]
    if branch:
        filtered = [d for d in filtered if d["branch"] == branch]
    if community:
        filtered = [d for d in filtered if d["community"] == community]

    return jsonify({"count": len(filtered), "rows": filtered})


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
